:HL["/_next/static/chunks/0neevhl_o1ozu.css","style"]
:HL["/_next/static/chunks/1889.nbn4tha9.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"D5EqlrxNynDIVGoLoX_DO"}
