1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0znttiqffa~ma.js","/_next/static/chunks/01wwa-n~857o..js","/_next/static/chunks/056x7lpk-tv_x.js","/_next/static/chunks/0ya-4-jps~ct4.js"],"default"]
3:I[37457,["/_next/static/chunks/0znttiqffa~ma.js","/_next/static/chunks/01wwa-n~857o..js","/_next/static/chunks/056x7lpk-tv_x.js","/_next/static/chunks/0ya-4-jps~ct4.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"D5EqlrxNynDIVGoLoX_DO"}
