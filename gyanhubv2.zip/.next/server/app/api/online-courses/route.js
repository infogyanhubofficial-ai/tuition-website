var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/online-courses/route.js")
R.c("server/chunks/[root-of-the-server]__0r9fgqn._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_online-courses_route_actions_0nvo~.t.js")
R.m(68475)
module.exports=R.m(68475).exports
