var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/online-courses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__13s7yf4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_online-courses_[id]_route_actions_0ovn9on.js")
R.m(48404)
module.exports=R.m(48404).exports
