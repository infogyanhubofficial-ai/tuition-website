globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/D5EqlrxNynDIVGoLoX_DO/_buildManifest.js",
    "static/D5EqlrxNynDIVGoLoX_DO/_ssgManifest.js",
    "static/D5EqlrxNynDIVGoLoX_DO/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/17nvg_xpf__d8.js",
    "static/chunks/0h4bq73pogmtb.js",
    "static/chunks/0enr6~6kfqjap.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-0aczv5fwi6237.js"
  ]
};
