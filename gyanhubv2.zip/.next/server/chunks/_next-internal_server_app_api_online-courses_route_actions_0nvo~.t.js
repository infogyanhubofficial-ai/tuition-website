module.exports=[42758,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_online-courses_route_actions_0nvo~.t.js.map