module.exports=[86278,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_become-a-tutor_page_actions_0r7ciu~.js.map