module.exports=[75193,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_online-courses_%5Bid%5D_page_actions_0-unrdd.js.map