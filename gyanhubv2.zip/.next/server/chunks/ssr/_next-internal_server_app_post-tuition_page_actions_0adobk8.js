module.exports=[83516,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_post-tuition_page_actions_0adobk8.js.map