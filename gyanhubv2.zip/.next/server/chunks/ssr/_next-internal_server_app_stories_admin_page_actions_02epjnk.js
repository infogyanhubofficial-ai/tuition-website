module.exports=[10500,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_stories_admin_page_actions_02epjnk.js.map