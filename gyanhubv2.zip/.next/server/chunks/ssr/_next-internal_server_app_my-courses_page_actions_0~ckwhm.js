module.exports=[74254,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-courses_page_actions_0~ckwhm.js.map