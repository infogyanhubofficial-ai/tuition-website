module.exports=[15418,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_online-courses_page_actions_0ijy2by.js.map