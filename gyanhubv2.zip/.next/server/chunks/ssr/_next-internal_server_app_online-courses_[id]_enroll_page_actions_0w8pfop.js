module.exports=[45699,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_online-courses_%5Bid%5D_enroll_page_actions_0w8pfop.js.map