module.exports=[38096,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tutors_%5Bid%5D_book_page_actions_0z4-.en.js.map