module.exports=[17669,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_online-courses_%5Bid%5D_route_actions_0ovn9on.js.map